
public interface Handler { //This class helps us to calculate different sums in our code.
	void execute(Integer num1, Integer numb2); 
}